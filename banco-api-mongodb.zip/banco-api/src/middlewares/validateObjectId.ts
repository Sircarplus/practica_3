import { Request, Response, NextFunction } from 'express';
import { esObjectIdValido } from '../utils/validators.js';

export function validarParamId(paramName: string = 'id') {
  return (req: Request, res: Response, next: NextFunction) => {
    const id = req.params[paramName];
    if (id && !esObjectIdValido(id)) {
      return res.status(400).json({ error: `El ID '${id}' no es un ObjectId válido` });
    }
    next();
  };
}
