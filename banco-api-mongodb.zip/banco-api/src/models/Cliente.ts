import { Schema, model, Document } from 'mongoose';

export interface ICliente extends Document {
  _id: string;
  nombre: string;
  email: string;
  dni: string;
  creadoEn: Date;
}

const clienteSchema = new Schema<ICliente>(
  {
    nombre: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    dni: { type: String, required: true, unique: true, uppercase: true, trim: true },
    creadoEn: { type: Date, default: Date.now }
  },
  {
    versionKey: false,
    toJSON: {
      transform: (_, ret) => {
        ret._id = ret._id.toString();
        ret.creadoEn = ret.creadoEn.toISOString();
        return ret;
      }
    }
  }
);

export const Cliente = model<ICliente>('Cliente', clienteSchema, 'clientes');
