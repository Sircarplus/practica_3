import { Schema, model, Document, Types } from 'mongoose';

export type TipoCuenta = 'corriente' | 'ahorro';
export type EstadoCuenta = 'activa' | 'bloqueada' | 'cerrada';

export interface ICuenta extends Document {
  _id: string;
  iban: string;
  clienteId: Types.ObjectId;
  tipo: TipoCuenta;
  saldo: number;
  descubiertoMax: number;
  estado: EstadoCuenta;
  creadaEn: Date;
}

const cuentaSchema = new Schema<ICuenta>(
  {
    iban: { type: String, required: true, unique: true, uppercase: true },
    clienteId: { type: Schema.Types.ObjectId, ref: 'Cliente', required: true },
    tipo: { type: String, enum: ['corriente', 'ahorro'], required: true },
    saldo: { type: Number, required: true, default: 0, validate: Number.isInteger },
    descubiertoMax: { type: Number, required: true, validate: Number.isInteger },
    estado: { type: String, enum: ['activa', 'bloqueada', 'cerrada'], default: 'activa' },
    creadaEn: { type: Date, default: Date.now }
  },
  {
    versionKey: false,
    toJSON: {
      transform: (_, ret) => {
        ret._id = ret._id.toString();
        ret.clienteId = ret.clienteId.toString();
        ret.creadaEn = ret.creadaEn.toISOString();
        return ret;
      }
    }
  }
);

export const Cuenta = model<ICuenta>('Cuenta', cuentaSchema, 'cuentas');
