import { Schema, model, Document, Types } from 'mongoose';

export type TipoMovimiento = 'ingreso' | 'retirada' | 'transferencia_emitida' | 'transferencia_recibida' | 'comision';

export interface IMovimiento extends Document {
  _id: string;
  cuentaId: Types.ObjectId;
  tipo: TipoMovimiento;
  importe: number;
  saldoResultante: number;
  concepto: string;
  categoria: string;
  transferenciaId?: Types.ObjectId;
  fecha: Date;
}

const movimientoSchema = new Schema<IMovimiento>(
  {
    cuentaId: { type: Schema.Types.ObjectId, ref: 'Cuenta', required: true, index: true },
    tipo: {
      type: String,
      enum: ['ingreso', 'retirada', 'transferencia_emitida', 'transferencia_recibida', 'comision'],
      required: true
    },
    importe: { type: Number, required: true, validate: Number.isInteger },
    saldoResultante: { type: Number, required: true, validate: Number.isInteger },
    concepto: { type: String, required: true, trim: true },
    categoria: { type: String, required: true, default: 'otros', trim: true },
    transferenciaId: { type: Schema.Types.ObjectId, index: true },
    fecha: { type: Date, default: Date.now, index: true }
  },
  {
    versionKey: false,
    toJSON: {
      transform: (_, ret) => {
        ret._id = ret._id.toString();
        ret.cuentaId = ret.cuentaId.toString();
        if (ret.transferenciaId) ret.transferenciaId = ret.transferenciaId.toString();
        ret.fecha = ret.fecha.toISOString();
        return ret;
      }
    }
  }
);

export const Movimiento = model<IMovimiento>('Movimiento', movimientoSchema, 'movimientos');
