import { Request, Response, NextFunction } from 'express';
import { Cliente } from '../models/Cliente.js';
import { validarDNI, validarEmail } from '../utils/validators.js';
import { parsearPaginacion } from '../utils/pagination.js';

export async function crearCliente(req: Request, res: Response, next: NextFunction) {
  try {
    const { nombre, email, dni } = req.body;

    if (!nombre || typeof nombre !== 'string' || !nombre.trim()) {
      return res.status(400).json({ error: 'El nombre es obligatorio' });
    }
    if (!email || !validarEmail(email)) {
      return res.status(400).json({ error: 'El email proporcionado no es válido' });
    }
    if (!dni || !validarDNI(dni)) {
      return res.status(400).json({ error: 'El DNI debe tener 8 dígitos y una letra válida' });
    }

    const emailClean = email.toLowerCase().trim();
    const dniClean = dni.toUpperCase().trim();

    const clienteExistente = await Cliente.findOne({
      $or: [{ email: emailClean }, { dni: dniClean }]
    });

    if (clienteExistente) {
      if (clienteExistente.email === emailClean) {
        return res.status(409).json({ error: 'El email ya está registrado' });
      }
      return res.status(409).json({ error: 'El DNI ya está registrado' });
    }

    const nuevoCliente = new Cliente({
      nombre: nombre.trim(),
      email: emailClean,
      dni: dniClean
    });

    await nuevoCliente.save();
    return res.status(201).json(nuevoCliente.toJSON());
  } catch (error) {
    next(error);
  }
}

export async function listarClientes(req: Request, res: Response, next: NextFunction) {
  try {
    const { pagina, limite, skip } = parsearPaginacion(req.query);

    const [datos, totalElementos] = await Promise.all([
      Cliente.find().skip(skip).limit(limite).exec(),
      Cliente.countDocuments()
    ]);

    const totalPaginas = Math.ceil(totalElementos / limite) || 1;

    return res.status(200).json({
      datos: datos.map((c) => c.toJSON()),
      pagina,
      limite,
      totalElementos,
      totalPaginas
    });
  } catch (error) {
    next(error);
  }
}

export async function obtenerClientePorId(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const cliente = await Cliente.findById(id);

    if (!cliente) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }

    return res.status(200).json(cliente.toJSON());
  } catch (error) {
    next(error);
  }
}

export async function actualizarCliente(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { nombre, email, dni } = req.body;

    if (dni !== undefined) {
      return res.status(409).json({ error: 'El DNI no se puede modificar' });
    }

    const cliente = await Cliente.findById(id);
    if (!cliente) {
      return res.status(404).json({ error: 'Cliente no encontrado' });
    }

    if (nombre !== undefined) {
      if (typeof nombre !== 'string' || !nombre.trim()) {
        return res.status(400).json({ error: 'El nombre debe ser una cadena no vacía' });
      }
      cliente.nombre = nombre.trim();
    }

    if (email !== undefined) {
      if (!validarEmail(email)) {
        return res.status(400).json({ error: 'El email proporcionado no es válido' });
      }
      const emailClean = email.toLowerCase().trim();
      if (emailClean !== cliente.email) {
        const duplicado = await Cliente.findOne({ email: emailClean, _id: { $ne: id } });
        if (duplicado) {
          return res.status(409).json({ error: 'El email ya está en uso por otro cliente' });
        }
        cliente.email = emailClean;
      }
    }

    await cliente.save();
    return res.status(200).json(cliente.toJSON());
  } catch (error) {
    next(error);
  }
}
