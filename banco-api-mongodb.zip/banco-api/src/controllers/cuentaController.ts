import { Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { Cuenta, EstadoCuenta } from '../models/Cuenta.js';
import { Cliente } from '../models/Cliente.js';
import { Movimiento } from '../models/Movimiento.js';
import { generarIbanEspanol } from '../utils/iban.js';
import { parsearPaginacion } from '../utils/pagination.js';
import { esObjectIdValido } from '../utils/validators.js';

export async function crearCuenta(req: Request, res: Response, next: NextFunction) {
  try {
    const { clienteId, tipo } = req.body;

    if (!clienteId || !esObjectIdValido(clienteId)) {
      return res.status(400).json({ error: 'El clienteId es obligatorio y debe ser un ObjectId válido' });
    }
    if (!tipo || !['corriente', 'ahorro'].includes(tipo)) {
      return res.status(400).json({ error: "El tipo de cuenta debe ser 'corriente' o 'ahorro'" });
    }

    const cliente = await Cliente.findById(clienteId);
    if (!cliente) {
      return res.status(404).json({ error: 'El cliente especificado no existe' });
    }

    const cuentasActivasOBloqueadas = await Cuenta.countDocuments({
      clienteId,
      estado: { $ne: 'cerrada' }
    });

    if (cuentasActivasOBloqueadas >= 3) {
      return res.status(409).json({ error: 'El cliente ya alcanzó el límite máximo de 3 cuentas activas o bloqueadas' });
    }

    const descubiertoMax = tipo === 'corriente' ? 50000 : 0;

    let cuentaCreada = null;
    let intentos = 0;

    while (!cuentaCreada && intentos < 10) {
      intentos++;
      const iban = generarIbanEspanol();
      try {
        const nuevaCuenta = new Cuenta({
          iban,
          clienteId,
          tipo,
          saldo: 0,
          descubiertoMax,
          estado: 'activa'
        });
        cuentaCreada = await nuevaCuenta.save();
      } catch (err: any) {
        if (err.code === 11000 && err.keyPattern?.iban) {
          continue;
        }
        throw err;
      }
    }

    if (!cuentaCreada) {
      return res.status(500).json({ error: 'No se pudo generar un IBAN único tras varios intentos' });
    }

    return res.status(201).json(cuentaCreada.toJSON());
  } catch (error) {
    next(error);
  }
}

export async function listarCuentas(req: Request, res: Response, next: NextFunction) {
  try {
    const { pagina, limite, skip } = parsearPaginacion(req.query);
    const { clienteId, tipo, estado } = req.query;

    const filtro: any = {};
    if (clienteId) {
      if (!esObjectIdValido(clienteId as string)) {
        return res.status(400).json({ error: 'El clienteId especificado en el filtro no es un ObjectId válido' });
      }
      filtro.clienteId = clienteId;
    }
    if (tipo) filtro.tipo = tipo;
    if (estado) filtro.estado = estado;

    const [datos, totalElementos] = await Promise.all([
      Cuenta.find(filtro).skip(skip).limit(limite).exec(),
      Cuenta.countDocuments(filtro)
    ]);

    const totalPaginas = Math.ceil(totalElementos / limite) || 1;

    return res.status(200).json({
      datos: datos.map((c) => c.toJSON()),
      pagina,
      limite,
      totalElementos,
      totalPaginas
    });
  } catch (error) {
    next(error);
  }
}

export async function obtenerCuentaPorId(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const cuenta = await Cuenta.findById(id).populate<{ clienteId: { nombre: string; email: string } }>('clienteId', 'nombre email');

    if (!cuenta) {
      return res.status(404).json({ error: 'Cuenta no encontrada' });
    }

    const obj: any = cuenta.toJSON();
    if (typeof cuenta.clienteId === 'object' && cuenta.clienteId !== null) {
      obj.clienteNombre = cuenta.clienteId.nombre;
      obj.clienteEmail = cuenta.clienteId.email;
    }

    return res.status(200).json(obj);
  } catch (error) {
    next(error);
  }
}

export async function cambiarEstadoCuenta(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { estado: nuevoEstado } = req.body;

    const estadosValidos: EstadoCuenta[] = ['activa', 'bloqueada', 'cerrada'];
    if (!nuevoEstado || !estadosValidos.includes(nuevoEstado)) {
      return res.status(400).json({ error: `El estado solicitado no es válido. Estados permitidos: ${estadosValidos.join(', ')}` });
    }

    const cuenta = await Cuenta.findById(id);
    if (!cuenta) {
      return res.status(404).json({ error: 'Cuenta no encontrada' });
    }

    const estadoActual = cuenta.estado;

    if (estadoActual === nuevoEstado) {
      return res.status(200).json(cuenta.toJSON());
    }

    if (estadoActual === 'cerrada') {
      return res.status(409).json({ error: `Transición no permitida: la cuenta está cerrada y su estado no se puede cambiar` });
    }

    if (nuevoEstado === 'cerrada') {
      if (cuenta.saldo !== 0) {
        return res.status(409).json({
          error: `No se puede cerrar una cuenta con saldo distinto de 0 (saldo actual: ${cuenta.saldo})`
        });
      }
    }

    cuenta.estado = nuevoEstado;
    await cuenta.save();

    return res.status(200).json(cuenta.toJSON());
  } catch (error) {
    next(error);
  }
}

export async function obtenerExtractoMovimientos(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const cuenta = await Cuenta.findById(id);
    if (!cuenta) {
      return res.status(404).json({ error: 'Cuenta no encontrada' });
    }

    const { pagina, limite, skip } = parsearPaginacion(req.query);
    const { tipo, categoria, desde, hasta, orden } = req.query;

    const filtro: any = { cuentaId: new mongoose.Types.ObjectId(id) };

    if (tipo) {
      const tiposArr = (tipo as string).split(',').map((t) => t.trim());
      filtro.tipo = { $in: tiposArr };
    }

    if (categoria) {
      filtro.categoria = categoria;
    }

    if (desde || hasta) {
      filtro.fecha = {};
      if (desde) {
        const fDesde = new Date(desde as string);
        if (isNaN(fDesde.getTime())) return res.status(400).json({ error: 'Parámetro desde fecha inválido' });
        filtro.fecha.$gte = fDesde;
      }
      if (hasta) {
        const fHasta = new Date(hasta as string);
        if (isNaN(fHasta.getTime())) return res.status(400).json({ error: 'Parámetro hasta fecha inválido' });
        filtro.fecha.$lte = fHasta;
      }
    }

    const sortOption: any = {};
    if (orden === 'fecha') {
      sortOption.fecha = 1;
    } else {
      sortOption.fecha = -1;
    }

    const [datos, totalElementos] = await Promise.all([
      Movimiento.find(filtro).sort(sortOption).skip(skip).limit(limite).exec(),
      Movimiento.countDocuments(filtro)
    ]);

    const totalPaginas = Math.ceil(totalElementos / limite) || 1;

    return res.status(200).json({
      datos: datos.map((m) => m.toJSON()),
      pagina,
      limite,
      totalElementos,
      totalPaginas
    });
  } catch (error) {
    next(error);
  }
}
