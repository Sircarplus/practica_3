import { Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import { Cuenta } from '../models/Cuenta.js';
import { Movimiento } from '../models/Movimiento.js';
import { validarIbanEspanol } from '../utils/iban.js';

async function obtenerRetiradasHoy(cuentaId: mongoose.Types.ObjectId): Promise<number> {
  const inicioHoy = new Date();
  inicioHoy.setUTCHours(0, 0, 0, 0);

  const finHoy = new Date();
  finHoy.setUTCHours(23, 59, 59, 999);

  const result = await Movimiento.aggregate([
    {
      $match: {
        cuentaId,
        tipo: { $in: ['retirada', 'transferencia_emitida'] },
        fecha: { $gte: inicioHoy, $lte: finHoy }
      }
    },
    {
      $group: {
        _id: null,
        total: { $sum: '$importe' }
      }
    }
  ]);

  if (result.length > 0) {
    return Math.abs(result[0].total);
  }
  return 0;
}

export async function ingresarDinero(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { importe, concepto, categoria } = req.body;

    if (!Number.isInteger(importe) || importe <= 0) {
      return res.status(400).json({ error: 'El importe debe ser un número entero positivo en céntimos' });
    }
    if (!concepto || typeof concepto !== 'string' || !concepto.trim()) {
      return res.status(400).json({ error: 'El concepto es obligatorio' });
    }

    const cuenta = await Cuenta.findById(id);
    if (!cuenta) {
      return res.status(404).json({ error: 'Cuenta no encontrada' });
    }

    if (cuenta.estado === 'cerrada') {
      return res.status(409).json({ error: 'No se pueden realizar ingresos en una cuenta cerrada' });
    }

    cuenta.saldo += importe;
    await cuenta.save();

    const movimiento = new Movimiento({
      cuentaId: cuenta._id,
      tipo: 'ingreso',
      importe,
      saldoResultante: cuenta.saldo,
      concepto: concepto.trim(),
      categoria: categoria ? categoria.trim() : 'otros'
    });

    await movimiento.save();

    return res.status(201).json(movimiento.toJSON());
  } catch (error) {
    next(error);
  }
}

export async function retirarDinero(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const { importe, concepto, categoria } = req.body;

    if (!Number.isInteger(importe) || importe <= 0) {
      return res.status(400).json({ error: 'El importe debe ser un número entero positivo en céntimos' });
    }
    if (!concepto || typeof concepto !== 'string' || !concepto.trim()) {
      return res.status(400).json({ error: 'El concepto es obligatorio' });
    }

    const cuenta = await Cuenta.findById(id);
    if (!cuenta) {
      return res.status(404).json({ error: 'Cuenta no encontrada' });
    }

    if (cuenta.estado === 'bloqueada') {
      return res.status(409).json({ error: 'No se pueden realizar retiradas en una cuenta bloqueada' });
    }
    if (cuenta.estado === 'cerrada') {
      return res.status(409).json({ error: 'No se pueden realizar retiradas en una cuenta cerrada' });
    }

    const disponible = cuenta.saldo + cuenta.descubiertoMax;
    if (cuenta.saldo - importe < -cuenta.descubiertoMax) {
      return res.status(409).json({
        error: `Saldo insuficiente: disponible ${disponible} céntimos (incluido descubierto), solicitado ${importe}`
      });
    }

    const acumuladoHoy = await obtenerRetiradasHoy(cuenta._id as any);
    if (acumuladoHoy + importe > 100000) {
      const disponibleDiario = Math.max(0, 100000 - acumuladoHoy);
      return res.status(409).json({
        error: `Límite diario de retiradas superado (100000 céntimos). Acumulado hoy: ${acumuladoHoy}, disponible restante: ${disponibleDiario}`
      });
    }

    cuenta.saldo -= importe;
    await cuenta.save();

    const movimiento = new Movimiento({
      cuentaId: cuenta._id,
      tipo: 'retirada',
      importe: -importe,
      saldoResultante: cuenta.saldo,
      concepto: concepto.trim(),
      categoria: categoria ? categoria.trim() : 'otros'
    });

    await movimiento.save();

    return res.status(201).json(movimiento.toJSON());
  } catch (error) {
    next(error);
  }
}

export async function realizarTransferencia(req: Request, res: Response, next: NextFunction) {
  try {
    const { ibanOrigen, ibanDestino, importe, concepto, categoria } = req.body;

    if (!validarIbanEspanol(ibanOrigen)) {
      return res.status(400).json({ error: 'El IBAN de origen no es válido' });
    }
    if (!validarIbanEspanol(ibanDestino)) {
      return res.status(400).json({ error: 'El IBAN de destino no es válido' });
    }

    const origenClean = ibanOrigen.toUpperCase().trim();
    const destinoClean = ibanDestino.toUpperCase().trim();

    if (origenClean === destinoClean) {
      return res.status(400).json({ error: 'Los IBAN de origen y destino deben ser diferentes' });
    }

    if (!Number.isInteger(importe) || importe <= 0) {
      return res.status(400).json({ error: 'El importe debe ser un número entero positivo en céntimos' });
    }
    if (!concepto || typeof concepto !== 'string' || !concepto.trim()) {
      return res.status(400).json({ error: 'El concepto es obligatorio' });
    }

    const cuentaOrigen = await Cuenta.findOne({ iban: origenClean });
    if (!cuentaOrigen) {
      return res.status(404).json({ error: 'La cuenta de origen no existe' });
    }

    const cuentaDestino = await Cuenta.findOne({ iban: destinoClean });
    if (!cuentaDestino) {
      return res.status(404).json({ error: 'La cuenta de destino no existe' });
    }

    if (cuentaOrigen.estado !== 'activa') {
      return res.status(409).json({ error: `La cuenta de origen debe estar activa (estado actual: ${cuentaOrigen.estado})` });
    }
    if (cuentaDestino.estado === 'cerrada') {
      return res.status(409).json({ error: 'La cuenta de destino está cerrada' });
    }

    let comision = 0;
    if (cuentaOrigen.clienteId.toString() !== cuentaDestino.clienteId.toString()) {
      comision = Math.ceil(importe * 0.005);
      if (comision < 100) comision = 100;
    }

    const totalADescontar = importe + comision;

    const disponible = cuentaOrigen.saldo + cuentaOrigen.descubiertoMax;
    if (cuentaOrigen.saldo - totalADescontar < -cuentaOrigen.descubiertoMax) {
      return res.status(409).json({
        error: `Saldo insuficiente: disponible ${disponible} céntimos (incluido descubierto), solicitado ${totalADescontar} (importe + comisión)`
      });
    }

    const acumuladoHoy = await obtenerRetiradasHoy(cuentaOrigen._id as any);
    if (acumuladoHoy + importe > 100000) {
      const disponibleDiario = Math.max(0, 100000 - acumuladoHoy);
      return res.status(409).json({
        error: `Límite diario superado (100000 céntimos). Acumulado hoy: ${acumuladoHoy}, disponible restante: ${disponibleDiario}`
      });
    }

    const transferenciaId = new mongoose.Types.ObjectId();
    const catFinal = categoria ? categoria.trim() : 'transferencias';
    const concFinal = concepto.trim();
    const fechaOperacion = new Date();

    cuentaOrigen.saldo -= totalADescontar;
    cuentaDestino.saldo += importe;

    await cuentaOrigen.save();
    await cuentaDestino.save();

    const movEmitida = new Movimiento({
      cuentaId: cuentaOrigen._id,
      tipo: 'transferencia_emitida',
      importe: -importe,
      saldoResultante: cuentaOrigen.saldo + (comision > 0 ? comision : 0),
      concepto: concFinal,
      categoria: catFinal,
      transferenciaId,
      fecha: fechaOperacion
    });
    await movEmitida.save();

    if (comision > 0) {
      const movComision = new Movimiento({
        cuentaId: cuentaOrigen._id,
        tipo: 'comision',
        importe: -comision,
        saldoResultante: cuentaOrigen.saldo,
        concepto: `Comisión transferencia: ${concFinal}`,
        categoria: 'comisiones',
        transferenciaId,
        fecha: fechaOperacion
      });
      await movComision.save();
    }

    const movRecibida = new Movimiento({
      cuentaId: cuentaDestino._id,
      tipo: 'transferencia_recibida',
      importe,
      saldoResultante: cuentaDestino.saldo,
      concepto: concFinal,
      categoria: catFinal,
      transferenciaId,
      fecha: fechaOperacion
    });
    await movRecibida.save();

    return res.status(201).json({
      transferenciaId: transferenciaId.toString(),
      importe,
      comision,
      saldoOrigen: cuentaOrigen.saldo,
      saldoDestino: cuentaDestino.saldo
    });
  } catch (error) {
    next(error);
  }
}
