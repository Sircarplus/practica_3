export function generarIbanEspanol(): string {
  let bban = '';
  for (let i = 0; i < 20; i++) {
    bban += Math.floor(Math.random() * 10).toString();
  }

  const tempStr = bban + '142800';
  const tempBigInt = BigInt(tempStr);
  const resto = tempBigInt % 97n;
  const digitoControl = 98n - resto;

  const controlStr = digitoControl < 10n ? `0${digitoControl}` : `${digitoControl}`;
  return `ES${controlStr}${bban}`;
}

export function validarIbanEspanol(iban: string): boolean {
  if (!iban || typeof iban !== 'string') return false;
  const clean = iban.replace(/\s+/g, '').toUpperCase();

  if (clean.length !== 24 || !clean.startsWith('ES')) return false;
  if (!/^ES\d{22}$/.test(clean)) return false;

  const rearranged = clean.slice(4) + clean.slice(0, 4);
  const numericStr = rearranged.replace(/E/g, '14').replace(/S/g, '28');

  try {
    const val = BigInt(numericStr);
    return val % 97n === 1n;
  } catch {
    return false;
  }
}
