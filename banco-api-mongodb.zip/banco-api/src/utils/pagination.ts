export interface PaginacionResult<T> {
  datos: T[];
  pagina: number;
  limite: number;
  totalElementos: number;
  totalPaginas: number;
}

export function parsearPaginacion(query: any) {
  let pagina = parseInt(query.pagina as string, 10);
  let limite = parseInt(query.limite as string, 10);

  if (isNaN(pagina) || pagina < 1) pagina = 1;
  if (isNaN(limite) || limite < 1) limite = 20;
  if (limite > 100) limite = 100;

  return { pagina, limite, skip: (pagina - 1) * limite };
}
