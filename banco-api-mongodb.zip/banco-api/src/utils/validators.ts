import mongoose from 'mongoose';

export function esObjectIdValido(id: string): boolean {
  return mongoose.Types.ObjectId.isValid(id) && new Date(id).toString() === 'Invalid Date' 
    ? id === new mongoose.Types.ObjectId(id).toString() 
    : mongoose.Types.ObjectId.isValid(id);
}

export function validarDNI(dni: string): boolean {
  if (!dni || typeof dni !== 'string') return false;
  const regex = /^\d{8}[A-Z]$/;
  const upper = dni.toUpperCase();
  if (!regex.test(upper)) return false;

  const letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
  const numero = parseInt(upper.substring(0, 8), 10);
  const letraEsperada = letras[numero % 23];

  return upper.charAt(8) === letraEsperada;
}

export function validarEmail(email: string): boolean {
  if (!email || typeof email !== 'string') return false;
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email.toLowerCase());
}
