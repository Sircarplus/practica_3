import mongoose from 'mongoose';

export async function conectarDB(uri: string): Promise<void> {
  try {
    await mongoose.connect(uri);
    console.log('Conexión exitosa a MongoDB');
  } catch (error) {
    console.error('Error al conectar con MongoDB:', error);
    process.exit(1);
  }
}
