import { Router } from 'express';
import {
  crearCuenta,
  listarCuentas,
  obtenerCuentaPorId,
  cambiarEstadoCuenta,
  obtenerExtractoMovimientos
} from '../controllers/cuentaController.js';
import { ingresarDinero, retirarDinero } from '../controllers/operacionController.js';
import { validarParamId } from '../middlewares/validateObjectId.js';

const router = Router();

router.post('/', crearCuenta);
router.get('/', listarCuentas);
router.get('/:id', validarParamId('id'), obtenerCuentaPorId);
router.patch('/:id/estado', validarParamId('id'), cambiarEstadoCuenta);
router.get('/:id/movimientos', validarParamId('id'), obtenerExtractoMovimientos);

router.post('/:id/ingresos', validarParamId('id'), ingresarDinero);
router.post('/:id/retiradas', validarParamId('id'), retirarDinero);

export default router;
