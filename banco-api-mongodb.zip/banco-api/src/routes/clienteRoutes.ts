import { Router } from 'express';
import {
  crearCliente,
  listarClientes,
  obtenerClientePorId,
  actualizarCliente
} from '../controllers/clienteController.js';
import { validarParamId } from '../middlewares/validateObjectId.js';

const router = Router();

router.post('/', crearCliente);
router.get('/', listarClientes);
router.get('/:id', validarParamId('id'), obtenerClientePorId);
router.patch('/:id', validarParamId('id'), actualizarCliente);

export default router;
