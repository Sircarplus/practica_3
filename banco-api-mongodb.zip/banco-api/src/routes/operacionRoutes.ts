import { Router } from 'express';
import { realizarTransferencia } from '../controllers/operacionController.js';

const router = Router();

router.post('/transferencias', realizarTransferencia);

export default router;
