import express from 'express';
import clienteRoutes from './routes/clienteRoutes.js';
import cuentaRoutes from './routes/cuentaRoutes.js';
import operacionRoutes from './routes/operacionRoutes.js';
import { errorHandler } from './middlewares/errorHandler.js';

const app = express();

app.use(express.json());

// Declaración de rutas
app.use('/clientes', clienteRoutes);
app.use('/cuentas', cuentaRoutes);
app.use('/', operacionRoutes);

// Manejo global de errores
app.use(errorHandler);

export default app;
