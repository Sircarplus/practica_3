import dotenv from 'dotenv';
dotenv.config();

import app from './app.js';
import { conectarDB } from './config/database.js';

const PORT = process.env.PORT || 3000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/banco_db';

async function bootstrap() {
  await conectarDB(MONGO_URI);
  app.listen(PORT, () => {
    console.log(`Servidor bancario escuchando en el puerto ${PORT}`);
  });
}

bootstrap();
